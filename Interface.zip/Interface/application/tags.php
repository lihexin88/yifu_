<?php
// 应用行为扩展定义文件
return [
    'app_init'     => [],    // 应用初始化
    'app_begin'    => [],    // 应用开始
    'module_init'  => [],   // 模块初始化
    'action_begin' => [],// 操作开始执行
    'view_filter'  => [], // 视图内容过滤
    'log_write'    => [],    // 日志写入
    'app_end'      => [],    // 应用结束
];
