<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/11
 * Time: 14:52
 */

namespace app\index\model;


use think\Model;

class UserAccount extends Model
{

}