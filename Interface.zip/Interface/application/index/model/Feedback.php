<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/12
 * Time: 10:01
 */

namespace app\index\model;


use think\Model;

class Feedback extends Model
{

}