<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/11
 * Time: 17:01
 */

namespace app\index\model;


use think\Model;

class FlowLog extends Model
{

}