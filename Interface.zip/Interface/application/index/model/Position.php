<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/11
 * Time: 16:49
 */

namespace app\index\model;


use think\Model;

class Position extends Model
{

}