<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/11
 * Time: 17:08
 */

namespace app\index\model;


use think\Model;

class Contract extends Model
{

}