<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/11
 * Time: 16:57
 */

namespace app\index\model;


use think\Model;

class Order extends Model
{

}