<?php
return [
    'connector' => 'Sync'
];
