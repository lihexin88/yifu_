<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"C:\wamp64\www\yifu\Interface\public/../application/index\view\withdrawal\index.html";i:1539393435;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>withdrawal</title>
</head>
<body>

this is withdrawal page

</body>
</html>