<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"C:\wamp64\www\yifu\Interface\public/../application/index\view\feedback\index.html";i:1539341322;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
    <meta charset="UTF-8">
    <title>index</title>
</head>
<body>
<div  id="myModels" style="border: 1px solid black;display: none;">
	asdf
</div>
<button onclick="shows()">点击</button>
<script type="text/javascript">
	function shows(){
		$("#myModels").modal("show");
	}
</script>
</body>
</html>