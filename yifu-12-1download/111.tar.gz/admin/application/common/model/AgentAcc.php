<?php

namespace app\common\model;

class AgentAcc extends \think\Model {

    protected $table = 'sn_agent_account';

}
