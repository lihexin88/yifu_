<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/20
 * Time: 14:46
 */

namespace app\common\model;


use think\Model;

class TradeControll extends Model
{

}