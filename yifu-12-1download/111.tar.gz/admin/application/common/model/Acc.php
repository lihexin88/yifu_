<?php

namespace app\common\model; 
use think\Model;

class Acc extends Model {

	protected $table = 'sn_account';

    
}
