<?php

namespace app\common\model;

class StaffAcc extends \think\Model {

    protected $table = 'sn_staff_account';

}
