<?php

namespace app\agent\model;
use think\Model;

class Bond extends Model {

	protected $table = 'sn_strategy_log';

}
