<?php

namespace app\agent\model;
use think\Model;
class Strategy extends Model {

    protected $table = 'sn_strategy_config';

}
