<?php

namespace app\agent\model;
use think\Db;

class UserBanks extends \think\Model {

    protected $table = 'sn_bank';
   
}
