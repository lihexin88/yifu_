<?php

namespace app\agent\model;
use think\Model;

class Bonds extends Model {

	protected $table = 'sn_flow_log';

}
