<?php

namespace app\agent\model;
use think\Model;

class Capital extends Model {

	protected $table = 'sn_trade_log';

}
